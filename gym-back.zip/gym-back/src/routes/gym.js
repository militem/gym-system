//RUTA DE LA API
const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const mysqlConnection = require('../database');
//OBTENER FECHA ACTUAL
const hoy = new Date();

function formatoFecha(fecha, formato) {
    const map = {
        dd: fecha.getDate(),
        mm: fecha.getMonth() + 1,
        yy: fecha.getFullYear().toString().slice(-2),
        yyyy: fecha.getFullYear()
    }
    return formato.replace(/dd|mm|yy|yyy/gi, matched => map[matched])
}
//Se devuelven todos usuarios
router.get('/api/users', (req, res) => {
    const token = req.headers['token'];
    var valid = false
    var user_name = ''
        //Se verifica que el token enviado sea el correcto
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        user_name = user.user_name
        valid = true
    });
    if (valid) {
        mysqlConnection.query('SELECT user_name, name, Date_format(date_of_creation, "%M %d de %Y") AS date_of_creation, rol, state FROM users WHERE user_name <> ?', [user_name], (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK',
                    rows: rows
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
//Se inserta un usuario
router.post('/api/useradd/', (req, res) => {
    const { user_name, password, name, rol } = req.body;
    const token = req.headers['token'];
    var date_of_creation = formatoFecha(hoy, 'yy/mm/dd');
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('INSERT INTO users VALUES(?, MD5(?), ?, ?, ?, "Habilitado")', [user_name, password, name, date_of_creation, rol], (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK'
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
//Se actualiza los datos de un usuario
router.post('/api/userupdate/', (req, res) => {
    const { user_name, name, rol, state } = req.body;
    //console.log(user_name);
    const token = req.headers['token'];
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('UPDATE users SET name = ?, rol = ?, state = ? WHERE user_name = ?', [name, rol, state, user_name], (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK'
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
//Se borra un usuario especifico
router.get('/api/userdelete/:user_name', (req, res) => {
    const { user_name } = req.params;
    const token = req.headers['token'];
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('DELETE FROM users WHERE user_name = ?', [user_name], (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK'
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
//Autenticar las credenciales para el login
router.post('/api/auth/', (req, res) => {
    const { user_name, password } = req.body
    let token = jwt.sign({ user_name }, 'gym-system-back', { expiresIn: '24h' });
    mysqlConnection.query('SELECT name FROM users WHERE user_name = ? AND password = MD5(?) AND state = "Habilitado"', [user_name, password], (err, rows, fields) => {
        if (!err) {
            result = {
                token: token,
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});
//Validar privilegios del usuario logeado
router.get('/api/validprivilege/', (req, res) => {
    const token = req.headers['token'];
    var valid = false
    var user_name = ''
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        user_name = user.user_name
        valid = true
    });
    if (valid) {
        mysqlConnection.query('SELECT rol FROM users WHERE user_name = ?', [user_name], (err, rows, fields) => {
            if (!err) {
                result = {
                    token: token,
                    msg: 'OK',
                    rows: rows
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
/*
    FUNCIONAMIENTO DE LA VISTA SOCIOS
*/
//OBTENER LOS DATOS DE LOS SOCIOS
router.get('/api/partners/', (req, res) => {
    const token = req.headers['token'];
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('SELECT CID, names, last_names, Date_format(date_of_born, "%M %d de %Y") AS date_of_born, phone_number, email, note, medical_history FROM socios', (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK',
                    rows: rows
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
});
//AÑADIR UN SOCIO EN LA BASE DE DATOS
router.post('/api/addpartner/', (req, res) => {
        const { CID, password, names, last_names, date_of_born, phone_number, email, note, medical_history, imagen_data } = req.body;
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        if (valid) {
            mysqlConnection.query('INSERT INTO socios VALUES(?, MD5(?), ?, ?, ?, ?, ?, ?, ?, ?)', [CID, password, names, last_names, date_of_born, phone_number, email, note, medical_history, imagen_data], (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK'
                    }
                    res.json(result);
                } else {
                    result = {
                        msg: 'error'
                    }
                    res.json(result);
                    console.log(err);
                }
            });
        }
    })
    //OBTENER LAS MEMBRESIAS DISPONIBLES PARA MOSTRAR EN EL SELECT DE LA VISTA SOCIOS 
router.get('/api/membershipsToPartners/', (req, res) => {
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        if (valid) {
            mysqlConnection.query('SELECT * FROM membership', (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK',
                        rows: rows
                    }
                    res.json(result);
                } else {
                    result = {
                        msg: 'error'
                    }
                    res.json(result);
                    console.log(err);
                }
            });
        }
    })
    //OBTENER LAS MEMBRESIAS
router.get('/api/memberships/', (req, res) => {
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        if (valid) {
            mysqlConnection.query('SELECT * FROM membership', (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK',
                        rows: rows
                    }
                    res.json(result);
                } else {
                    result = {
                        msg: 'error'
                    }
                    res.json(result);
                    console.log(err);
                }
            });
        }
    })
    //AÑADIR UN SOCIO EN LA BASE DE DATOS
router.post('/api/addmembership/', (req, res) => {
    const { name, days, price } = req.body;
    const token = req.headers['token'];
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('INSERT INTO membership VALUES(NULL, ?, ?, ?)', [name, days, price], (err, rows, fields) => {
            if (!err) {
                result = {
                    msg: 'OK'
                }
                res.json(result);
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
})

//OBTENER PAGOS DE SOCIOS
router.get('/api/getPayments/', (req, res) => {
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        if (valid) {
            mysqlConnection.query('SELECT id_pago, id_sociosMembership, CID, mount, state, Date_format(date_of_pay, "%M %d de %Y") AS date_of_pay FROM sociospago', (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK',
                        rows: rows
                    }
                    res.json(result);
                } else {
                    result = {
                        msg: 'error'
                    }
                    res.json(result);
                    console.log(err);
                }
            });
        }
    })
    //OBTENER MEMBRESIAS DE CADA SOCIO
router.post('/api/getSocioMemberships/', (req, res) => {
        const { CID } = req.body;
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        if (valid) {
            mysqlConnection.query('SELECT id_sociosMembership, CID, days_consumed, state, Date_format(date_of_creation, "%M %d de %Y") AS date_of_creation FROM sociosmembership WHERE CID = ?', [CID], (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK',
                        rows: rows
                    }
                    res.json(result);
                } else {
                    result = {
                        msg: 'error'
                    }
                    res.json(result);
                    console.log(err);
                }
            });
        }
    })
    //AGREGAR MEMBRESIAS A CADA SOCIO
router.post('/api/addSocioMemberships/', (req, res) => {
        const { membershipName, CID } = req.body;
        const token = req.headers['token'];
        var valid = false
        if (token == null) return res.sendStatus(403);
        jwt.verify(token, 'gym-system-back', (err, user) => {
            if (err) return res.sendStatus(404);
            req.user = user;
            valid = true
        });
        var price = null;
        var id_sociosMembership_new = null;
        if (valid) {
            mysqlConnection.query('SELECT id_sociosMembership FROM sociosmembership ORDER BY id_sociosMembership DESC LIMIT 1 ', (err, rows, fields) => {
                if (!err) {
                    id = {
                        msg: 'OK',
                        rows: rows
                    }
                    if (id.rows.length == 0) {
                        id_sociosMembership_new = 10000;
                    } else {
                        id_sociosMembership_new = id.rows[0].id_sociosMembership + 1;
                    }
                }
            })
            mysqlConnection.query('SELECT * FROM membership WHERE name = ?', [membershipName], (err, rows, fields) => {
                if (!err) {
                    result = {
                        msg: 'OK',
                        rows: rows
                    }
                    price = result.rows[0].price;
                    mysqlConnection.query('INSERT INTO sociosmembership VALUES(?, ?, ?, 0, "Inactivo", NOW())', [id_sociosMembership_new, CID, result.rows[0].id_membership], (err, rows, fields) => {
                        if (!err) {
                            mysqlConnection.query('INSERT INTO sociospago VALUES(NULL, ?,?, ?, "No Pagado", Null)', [id_sociosMembership_new, CID, price], (err, rows, fields) => {
                                result = {
                                    msg: 'OK'
                                }
                            });
                            res.json(result);
                        } else {
                            result = {
                                msg: 'error'
                            }
                            res.json(result);
                            console.log(err);
                        }
                    });
                } else {
                    result = {
                        msg: 'error'
                    }
                    console.log(err);
                }
            });
        }
    })
    //PAGAR LAS MEMBRESIAS
router.post('/api/pay/', (req, res) => {
    const { id_pago, id_sociosMembership, CID } = req.body;
    const token = req.headers['token'];
    var valid = false
    if (token == null) return res.sendStatus(403);
    jwt.verify(token, 'gym-system-back', (err, user) => {
        if (err) return res.sendStatus(404);
        req.user = user;
        valid = true
    });
    if (valid) {
        mysqlConnection.query('UPDATE sociospago SET state = "Pagado", date_of_pay = NOW() WHERE id_pago = ? AND CID = ?', [id_pago, CID], (err, rows, fields) => {
            if (!err) {
                mysqlConnection.query('UPDATE sociosmembership SET state = "Activo" WHERE id_sociosMembership = ? AND CID = ?', [id_sociosMembership, CID], (err, rows, fields) => {
                    result = {
                        msg: 'OK'
                    }
                    res.json(result);
                })
            } else {
                result = {
                    msg: 'error'
                }
                res.json(result);
                console.log(err);
            }
        });
    }
})
module.exports = router;